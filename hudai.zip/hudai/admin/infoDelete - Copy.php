<?php
	
	include('../connectDB.php');

	$id =$_REQUEST['id'];
	
	
	// sending query
	mysql_query("DELETE FROM drop_info WHERE id = '$id'")
	or die(mysql_error());  	
	
	header('location:./info.php');
?>
