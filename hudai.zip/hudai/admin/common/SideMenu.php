            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">

                        <div class="menu_section">
                            
             
                            <ul class="nav side-menu" >
                                <li><a><i class="fa fa-home"></i>ADMIN SETUP MENU <span class="fa fa-chevron-down"></span></a>
                                    <ul class="nav child_menu" style="display: none">
                             
                                        <li><a href="info.php">Basic Info</a>
                                        </li>

                                        <li><a href="user.php">User</a>
                                        </li>
                                        
                                    </ul>
                                </li>
                                
                            </ul>
                        </div>
                    

                    </div>