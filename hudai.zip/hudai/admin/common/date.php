                    <?php
      $Today = date('y:m:d',time());
      $new = date('l, F d, Y', strtotime($Today));
      echo $new;
      ?>

              <?php
      $date_time=date("h:i:sa", strtotime("+5 hours"));
      
      echo $date_time;
      ?>