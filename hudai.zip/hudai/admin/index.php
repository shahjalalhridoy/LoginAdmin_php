 
<?php
    include_once('connectDb.php')   ; 
?> 


 <?php
        include_once('common/header.php');
    ?>

<body class="nav-md">

    <div class="container body">


        <div class="main_container">

            <div class="col-md-3 left_col">
                <div class="left_col scroll-view">

                  
                    <!-- /menu prile quick info -->

                    <br />

                    <!-- sidebar menu -->
        

        <?php
        include_once('common/SideMenu.php');
    ?>
      
                </div>
            </div>

            <!-- top navigation -->
            <div class="top_nav">

                <div class="nav_menu">

                    <nav class="" role="navigation">


                        <div class="nav toggle">
                            <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                        </div>

                      
                </div>

            </div>
            <!-- /top navigation -->

            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">

                    <div class="page-title">
                        <div class="title_rigth">
                            <h3>
                     <h3>
                        <?php
                            echo "<p>Welcome ".$_SESSION['user']." "."<a href=\"../logout.php\" class=\"btn btn-info btn-xs\">Log Out</a>"."</p>";
                        ?>

                            </h3>
                    <small>
                    <!--  Some examples to get you started-->
                    </small>
                </h3>
                        </div>

                       
                    <div class="clearfix"></div>

                    <div class="row">

                        <div class="col-md-12">
                            <div class="x_panel">
                                <div class="x_title">
                                   <!-- <h2> SoftRithm<small>POSPLUS</small></h2>-->
                             
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">


                                    <div class="row">

                                        <div class="col-sm-3 mail_list_column">

                                         
                                            



                                        </div>
                                


                             
                                        <div class="col-sm-9 mail_view">
                                            <div class="inbox-body">
                                           <div class="mail_heading row">
                             








                                                    <div class="col-md-4 text-right">
                                                        <p class="date"> </p>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <h1>Admin Panel<br/>  </h1><h2>     <?php
        include_once('common/date.php');
    ?></h2>


                                                    </div>
                                                </div>
                                              
















                                           
                                            </div>

                                        </div>
                                   
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<!-- Content-->
                <!-- footer content -->
              <?php

              include_once('common/footer.php');


              ?>