 
<?php
    include_once('connectDb.php')   ; 
?> 


 <?php
        include_once('common/header.php');
    ?>

<body class="nav-md">

    <div class="container body">


        <div class="main_container">

            <div class="col-md-3 left_col">
                <div class="left_col scroll-view">

                  
                    <!-- /menu prile quick info -->

                    <br />

                    <!-- sidebar menu -->
        

        <?php
        include_once('common/SideMenu.php');
    ?>
      
                </div>
            </div>

            <!-- top navigation -->
            <div class="top_nav">

                <div class="nav_menu">

                    <nav class="" role="navigation">


                        <div class="nav toggle">
                            <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                        </div>

                      
                </div>

            </div>
            <!-- /top navigation -->

              <div class="right_col" role="main">
                <div class="">

                    <div class="page-title">

                           <?php
        include_once('common/date.php');
    ?>
                        <div class="title_rigth">
                            <h3>
                     <h3>
                        <?php
                            echo "<p>Welcome ".$_SESSION['user']." "."<a href=\"../logout.php\" class=\"btn btn-info btn-xs\">Log Out</a>"."</p>";
                        ?>

                            </h3>
                    <small>
                    <!--  Some examples to get you started-->
                    </small>
                </h3>
                        </div>

                       
                    <div class="clearfix"></div>

                    <div class="row">

                        <div class="col-md-12">
                            <div class="x_panel">
                                <div class="x_title">
                                   <!-- <h2> SoftRithm<small>POSPLUS</small></h2>-->
                             
                                    <div class="clearfix"></div>
                                </div>



               





<?php

mysql_connect('localhost', 'root', '');

mysql_select_db('app');

$sql="SELECT * FROM drop_info";

$records=mysql_query($sql);

?>

                       
                                       <div class="clearfix"></div>

                    <div class="row">

                        <div class="col-md-12">
                            <div class="x_panel">
                                <div class="x_title">
                                 <h2>All info<small>
                                     

                

                                 </small></h2>
                                  
                                


                                    <table id="example" class="table table-striped responsive-utilities jambo_table">
                                        <thead>
                                            <tr class="headings">
                                                <th>SL No</th> 
                                                <th>Name </th>
                                                <th>Title</th>
                                                <th>Boby </th>
                                                <th>Latitude</th>
                                                <th>Longitude</th>
                                                 <th>Range</th>
                                               
                                                <th>Action</th>
                                               
                                              
                                                </th>
                                            </tr>
                                        </thead>

                                       <?php

$sl = 1;
while($info=mysql_fetch_assoc($records))
{ 
        

      $id = $info['id'];  

    echo "<tr>";

    echo "<td>".$sl."</td>";

    echo "<td>".$info['user_name']."</td>";

    echo "<td>".$info['title']."</td>";


        echo "<td>".$info['body']."</td>";

    echo "<td>".$info['lati']."</td>";


        echo "<td>".$info['longi']."</td>";

        echo "<td>".$info['raange']."</td>";


         echo "<td><button type=\"button\" class=\"btn btn-info btn-sm edit-delete-margin\">Edit</button>";
        echo "<button type=\"button\" class=\"btn btn-danger btn-sm\"><a href ='infoDelete.php?id=$id'>Delete</a></button></td>";




    echo "</tr>";

        

  $sl++;                

}
?>
</table>
                  <!-- /CONTENT MAIL -->
                                    </div>
                                </div>
                            </div>
                        </div>
            </nav>
                        <?php

              include_once('common/footer.php');


              ?>



                        
                            </div>
                        </div>
                    </div>
                </div>
<!-- Content-->
                <!-- footer content -->
              <?php

              include_once('common/footer.php');


              ?>



